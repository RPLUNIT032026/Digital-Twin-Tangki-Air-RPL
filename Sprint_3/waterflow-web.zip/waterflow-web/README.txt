WaterFlow - Smart Water Tank (web)
1. Buka folder ini di VS Code (File > Open Folder).
2. Install ekstensi "Live Server" (Ritwick Dey).
3. Klik kanan index.html > Open with Live Server.
