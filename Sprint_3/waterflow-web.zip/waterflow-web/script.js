// ===== Data (state) =====
const state = { level: 68, max: 90, user: "Pengguna" };
const SCALE = 100; // tinggi tangki 0-100 cm

// ===== Elemen =====
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);
const screens = $$(".screen");
const nav = $("#bottomNav");
const toast = $("#toast");

// ===== Pindah layar =====
function show(id) {
  screens.forEach((s) => s.classList.toggle("active", s.id === id));
  const withNav = ["home", "limit", "profile"].includes(id);
  nav.hidden = !withNav;
  $$("#bottomNav button").forEach((b) => b.classList.toggle("active", b.dataset.go === id));
  if (id === "limit") $("#maxInput").value = state.max;
}

function notify(msg) {
  toast.textContent = msg;
  toast.hidden = false;
  clearTimeout(notify.t);
  notify.t = setTimeout(() => (toast.hidden = true), 2200);
}

// ===== Tampilan data =====
function render() {
  const reached = state.level >= state.max;

  $$("[data-level]").forEach((e) => (e.textContent = state.level));
  $$("[data-max]").forEach((e) => (e.textContent = state.max));
  $$("[data-fill]").forEach((e) => (e.style.height = Math.min(state.level, SCALE) + "%"));
  $$("[data-line]").forEach((e) => (e.style.bottom = Math.min(state.max, SCALE) + "%"));

  $("#home").classList.toggle("danger", reached);
  $("#alertBanner").hidden = !reached;

  const badge = $("#badge");
  badge.textContent = reached ? "Batas tercapai" : "Aman";
  badge.className = "badge " + (reached ? "badge-danger" : "badge-ok");

  $("#valStatus").textContent = reached ? "Batas tercapai" : "Batas belum tercapai";
  const pump = $("#valPump");
  pump.textContent = reached ? "Berhenti" : "Mengisi";
  const alarm = $("#valAlarm");
  alarm.textContent = reached ? "Berbunyi" : "Siaga";
  alarm.className = reached ? "danger" : "";
}

// ===== Splash -> Login =====
$("#splash").addEventListener("click", () => show("login"));
setTimeout(() => { if ($("#splash").classList.contains("active")) show("login"); }, 2500);

// ===== Login =====
$("#togglePass").addEventListener("click", () => {
  const p = $("#pass");
  p.type = p.type === "password" ? "text" : "password";
});
$("#forgot").addEventListener("click", (e) => { e.preventDefault(); notify("Fitur lupa password belum tersedia"); });

$("#loginForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const u = $("#user").value.trim();
  const p = $("#pass").value.trim();
  if (!u || !p) { $("#loginError").hidden = false; return; }
  $("#loginError").hidden = true;
  state.user = u;
  $("#profName").textContent = u;
  render();
  show("home");
});

// ===== Navigasi =====
$$("#bottomNav button").forEach((b) => b.addEventListener("click", () => show(b.dataset.go)));
$("#goSet").addEventListener("click", () => show("limit"));
$("#backBtn").addEventListener("click", () => show("home"));

// ===== Simpan batas =====
$("#saveBtn").addEventListener("click", () => {
  const v = Number($("#maxInput").value);
  if (!Number.isFinite(v) || v < 10 || v > SCALE) { $("#limitError").hidden = false; return; }
  $("#limitError").hidden = true;
  state.max = Math.round(v);
  render();
  notify("Batas maksimum disimpan: " + state.max + " cm");
  show("home");
});

// ===== Keluar =====
$("#logoutBtn").addEventListener("click", () => {
  $("#pass").value = "";
  show("login");
});

// ===== Simulasi sensor =====
const setLevel = (n) => { state.level = Math.max(0, Math.min(SCALE, n)); render(); };
$("#simUp").addEventListener("click", () => setLevel(state.level + 8));
$("#simDown").addEventListener("click", () => setLevel(state.level - 8));
$("#simReset").addEventListener("click", () => setLevel(68));

render();
